import numpy as np
from colorama import Fore, Style
import os
import msvcrt
import random

filas = 10
columnas = 7

alumnos = np.empty([filas, columnas], object)

def limpiarpantalla():
    printc("<<PRESS ANY KEY TO CONTINUE>>")
    msvcrt.getche()
    os.system('cls')

def printr(texto):
    print(f"{Fore.RED}{Style.BRIGHT}{texto}{Fore.RESET}{Style.RESET_ALL}")

def printv(texto):
    print(f"{Fore.GREEN}{Style.BRIGHT}{texto}{Fore.RESET}{Style.RESET_ALL}")

def printc(texto):
    print(f"{Fore.CYAN}{Style.BRIGHT}{texto}{Fore.RESET}{Style.RESET_ALL}")

def printa(texto):
    print(f"{Fore.YELLOW}{Style.BRIGHT}{texto}{Fore.RESET}{Style.RESET_ALL}")

def titulo(texto):
    printv("*********************************")
    printc(f"   {texto.upper()}")
    printv("*********************************")

def validarrut(rut):
    for i in range(filas):
        if alumnos[i,0]==rut:
            return i 
        return -1 

def registrar(rut, nombre_completo, edad, genero, promedio_notas, fecha_matricula, nombre_apoderado):
    if None in alumnos:
        for i in range(columnas):
            alumnos[i,0]==None
            alumnos[i,0]==rut
            alumnos[i,1]==nombre_completo
            alumnos[i,2]==edad
            alumnos[i,3]==genero 
            alumnos[i,4]==promedio_notas
            alumnos[i,5]==fecha_matricula
            alumnos[i,6]==nombre_apoderado

def buscar():


anotaciones = []

anotaciones.append("")
anotaciones.append("")
anotaciones.append("")
anotaciones.append("")
anotaciones.append("")
anotaciones.append("")

certificado = []