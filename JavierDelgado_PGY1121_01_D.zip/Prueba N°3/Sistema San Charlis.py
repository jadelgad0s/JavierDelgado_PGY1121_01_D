import MisFunciones as mf


while True:
    mf.limpiarpantalla()
    mf.titulo("SISTEMA COLEGIO San Charlis")
    mf.printa("1) Registrar")
    mf.printa("2) Buscar")
    mf.printa("3) Certificado ")
    mf.printa("0) Salir")
    opcion = int(input("Seleccione: "))

    if opcion==0:
        break
    elif opcion==1:
        mf.titulo("Registrar datos del Alumno")
        rut = input("Ingrese RUT del Alumno (Sin puntos y con guion): ")
        nombre_completo = input("Ingrese nombre completo del Alumno : ")
        edad = int(input("Ingrese edad del Alumno: "))
        genero = input("Ingrese género del Alumno (M/F): ").upper()
        promedio_notas = float(input("Ingrese promedio de notas del Alumno: "))
        fecha_matricula = input("Ingrese fecha de la matricula del Alumno (DD/MM/AAAA): ")
        nombre_apoderado = input("Ingrese nombre del apoderado: ")
        if rut==10:
            pass
        else:
            mf.printr("EL RUT ESTA ERRONEO")
            if nombre_completo>=2 and nombre_completo<=30:
                pass 
            else:
                mf.printr("EL NOMBRE DEL ALUMNO DEBE TENER ENTRE 2 Y 30 CARACTERES")
                if edad>=4:
                    pass
                else:
                    mf.printr("LA EDAD DEBE SER MAYOR O IGUAL A 4")
                    if genero=="M" or genero=="F":
                        pass
                    else:
                        mf.printr("DEBES USAR M O F PARA EL GÉNERO")

    elif opcion==2:
        mf.titulo("Buscar Alumno")
        rut = int(input("Ingrese Rut del Alumno: "))
    elif opcion==3:
        mf.titulo("Imprimir Certificado")
        mf.printc("1) anotaciones de un alumno: ")
        mf.printc("2) certificado de notas: ")
        mf.printc("3) certificado de alumno regular: ")

    else:
        mf.printr("OPCIÓN NO VALIDA")



